// West Marches Extension - Background Service Worker

// Firebase config (same as westmarches web app)
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyDpqO9qAw3sJUxMEJpUYOHwPnFV-s9gFz4",
  authDomain: "westmarches-dnd.firebaseapp.com",
  projectId: "westmarches-dnd",
  storageBucket: "westmarches-dnd.firebasestorage.app",
  messagingSenderId: "1084465200262",
  appId: "1:1084465200262:web:1c0c42ac8c8d13582da507"
}

// Google OAuth Client ID (for Chrome extension)
const OAUTH_CLIENT_ID = '1084465200262-r01sd51huantpkto1tvv9j7uir9fvvmg.apps.googleusercontent.com'

// Refresh Firebase token if expired
async function getValidToken() {
  const { token, refreshToken } = await chrome.storage.local.get(['token', 'refreshToken'])
  if (!token || !refreshToken) return null
  
  // Try to use current token first, refresh if needed
  try {
    // Check if token is expired by making a simple request
    const testResponse = await fetch(
      `https://firestore.googleapis.com/v1/projects/${FIREBASE_CONFIG.projectId}/databases/(default)/documents/test`,
      { headers: { 'Authorization': `Bearer ${token}` } }
    )
    
    // 401 or 403 means token expired
    if (testResponse.status === 401 || testResponse.status === 403) {
      console.log('Token expired, refreshing...')
      const refreshResponse = await fetch(
        `https://securetoken.googleapis.com/v1/token?key=${FIREBASE_CONFIG.apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `grant_type=refresh_token&refresh_token=${refreshToken}`
        }
      )
      
      const refreshData = await refreshResponse.json()
      if (refreshData.error) {
        console.error('Token refresh failed:', refreshData.error)
        return null
      }
      
      // Update stored token
      await chrome.storage.local.set({ 
        token: refreshData.id_token,
        refreshToken: refreshData.refresh_token 
      })
      
      return refreshData.id_token
    }
    
    return token
  } catch (err) {
    console.error('Token validation error:', err)
    return token // Return existing token and let the request fail if invalid
  }
}

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'bookmark') {
    handleBookmarkRequest(request).then(sendResponse)
    return true
  }
  if (request.action === 'login') {
    if (request.method === 'email') {
      handleEmailLogin(request.email, request.password).then(sendResponse)
    } else {
      handleGoogleLogin().then(sendResponse)
    }
    return true // async response
  }
  if (request.action === 'logout') {
    handleLogout().then(sendResponse)
    return true
  }
  if (request.action === 'getUser') {
    chrome.storage.local.get(['user', 'token']).then(sendResponse)
    return true
  }
  if (request.action === 'getSettings') {
    chrome.storage.local.get(['settings']).then(result => {
      sendResponse(result.settings || {})
    })
    return true
  }
  if (request.action === 'broadcast') {
    broadcastToContentScripts(request.payload)
    sendResponse({ success: true })
    return false
  }
  if (request.action === 'firestore') {
    handleFirestoreRequest(request).then(sendResponse)
    return true
  }
})

// Handle Google login via Chrome identity API
async function handleGoogleLogin() {
  try {
    // Use chrome.identity for OAuth flow
    const redirectUrl = chrome.identity.getRedirectURL()
    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth')
    authUrl.searchParams.set('client_id', OAUTH_CLIENT_ID)
    authUrl.searchParams.set('redirect_uri', redirectUrl)
    authUrl.searchParams.set('response_type', 'token')
    authUrl.searchParams.set('scope', 'openid email profile')
    
    const responseUrl = await chrome.identity.launchWebAuthFlow({
      url: authUrl.toString(),
      interactive: true
    })
    
    // Extract token from response URL
    const url = new URL(responseUrl)
    const params = new URLSearchParams(url.hash.substring(1))
    const accessToken = params.get('access_token')
    
    if (!accessToken) {
      throw new Error('No access token received')
    }
    
    // Get user info from Google
    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${accessToken}` }
    })
    const userInfo = await userInfoResponse.json()
    
    // Exchange Google token for Firebase token
    const firebaseToken = await exchangeGoogleTokenForFirebase(accessToken)
    
    const user = {
      uid: firebaseToken.localId,
      email: userInfo.email,
      displayName: userInfo.name,
      photoURL: userInfo.picture
    }
    
    // Store in chrome.storage
    await chrome.storage.local.set({ 
      user, 
      token: firebaseToken.idToken,
      refreshToken: firebaseToken.refreshToken
    })
    
    // Notify content scripts
    broadcastToContentScripts({ action: 'authStateChanged', user })
    
    return { success: true, user }
  } catch (err) {
    console.error('Google login failed:', err)
    return { success: false, error: err.message }
  }
}

// Handle email/password login
async function handleEmailLogin(email, password) {
  try {
    const response = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FIREBASE_CONFIG.apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          returnSecureToken: true
        })
      }
    )
    
    const data = await response.json()
    if (data.error) {
      let errorMessage = data.error.message
      // Make error messages more user-friendly
      if (errorMessage === 'EMAIL_NOT_FOUND') errorMessage = 'Email not found'
      if (errorMessage === 'INVALID_PASSWORD') errorMessage = 'Invalid password'
      if (errorMessage === 'INVALID_LOGIN_CREDENTIALS') errorMessage = 'Invalid email or password'
      throw new Error(errorMessage)
    }
    
    const user = {
      uid: data.localId,
      email: data.email,
      displayName: data.displayName || data.email.split('@')[0],
      photoURL: data.profilePicture || null
    }
    
    // Store in chrome.storage
    await chrome.storage.local.set({ 
      user, 
      token: data.idToken,
      refreshToken: data.refreshToken
    })
    
    // Notify content scripts
    broadcastToContentScripts({ action: 'authStateChanged', user })
    
    return { success: true, user }
  } catch (err) {
    console.error('Email login failed:', err)
    return { success: false, error: err.message }
  }
}

// Exchange Google OAuth token for Firebase ID token
async function exchangeGoogleTokenForFirebase(googleAccessToken) {
  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${FIREBASE_CONFIG.apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requestUri: 'https://westmarches-dnd.firebaseapp.com',
        postBody: `access_token=${googleAccessToken}&providerId=google.com`,
        returnSecureToken: true,
        returnIdpCredential: true
      })
    }
  )
  
  const data = await response.json()
  if (data.error) {
    throw new Error(data.error.message)
  }
  
  return data
}

// Handle logout
async function handleLogout() {
  await chrome.storage.local.remove(['user', 'token', 'refreshToken'])
  broadcastToContentScripts({ action: 'authStateChanged', user: null })
  return { success: true }
}

// Broadcast message to all D&D Beyond content scripts
async function broadcastToContentScripts(message) {
  const tabs = await chrome.tabs.query({ url: ['https://www.dndbeyond.com/*', 'https://*.dndbeyond.com/*'] })
  for (const tab of tabs) {
    try {
      await chrome.tabs.sendMessage(tab.id, message)
    } catch (e) {
      // Tab might not have content script loaded
    }
  }
}

// Handle Firestore requests from content scripts
async function handleFirestoreRequest(request) {
  const { token } = await chrome.storage.local.get(['token'])
  if (!token) {
    return { success: false, error: 'Not authenticated' }
  }
  
  const { collection, action, data, docId } = request
  const baseUrl = `https://firestore.googleapis.com/v1/projects/${FIREBASE_CONFIG.projectId}/databases/(default)/documents`
  
  try {
    if (action === 'list') {
      const response = await fetch(`${baseUrl}/${collection}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      const result = await response.json()
      return { success: true, documents: result.documents || [] }
    }
    
    if (action === 'get') {
      const response = await fetch(`${baseUrl}/${collection}/${docId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      const result = await response.json()
      return { success: true, document: result }
    }
    
    if (action === 'create') {
      const response = await fetch(`${baseUrl}/${collection}`, {
        method: 'POST',
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ fields: convertToFirestoreFields(data) })
      })
      const result = await response.json()
      return { success: true, document: result }
    }
    
    return { success: false, error: 'Unknown action' }
  } catch (err) {
    console.error('Firestore error:', err)
    return { success: false, error: err.message }
  }
}

// Convert JS object to Firestore field format
function convertToFirestoreFields(obj) {
  const fields = {}
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string') {
      fields[key] = { stringValue: value }
    } else if (typeof value === 'number') {
      fields[key] = Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value }
    } else if (typeof value === 'boolean') {
      fields[key] = { booleanValue: value }
    } else if (Array.isArray(value)) {
      fields[key] = { arrayValue: { values: value.map(v => ({ stringValue: String(v) })) } }
    } else if (value === null) {
      fields[key] = { nullValue: null }
    } else if (value instanceof Date) {
      fields[key] = { timestampValue: value.toISOString() }
    }
  }
  return fields
}

// Handle keyboard commands
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.id) return
  
  if (command === 'toggle-command-palette') {
    chrome.tabs.sendMessage(tab.id, { action: 'toggleCommandPalette' })
  } else if (command === 'toggle-sidebar') {
    chrome.tabs.sendMessage(tab.id, { action: 'toggleSidebar' })
  }
})

// Handle bookmark (star) requests
async function handleBookmarkRequest(request) {
  const { user } = await chrome.storage.local.get(['user'])
  const token = await getValidToken()
  if (!token || !user) {
    return { success: false, error: 'Not authenticated - please log in via the extension popup' }
  }
  
  const baseUrl = `https://firestore.googleapis.com/v1/projects/${FIREBASE_CONFIG.projectId}/databases/(default)/documents`
  
  try {
    if (request.method === 'check') {
      // Check if URL is bookmarked by querying with filter
      const query = {
        structuredQuery: {
          from: [{ collectionId: 'userBookmarks' }],
          where: {
            compositeFilter: {
              op: 'AND',
              filters: [
                { fieldFilter: { field: { fieldPath: 'userId' }, op: 'EQUAL', value: { stringValue: user.uid } } },
                { fieldFilter: { field: { fieldPath: 'url' }, op: 'EQUAL', value: { stringValue: request.url } } }
              ]
            }
          },
          limit: 1
        }
      }
      
      const response = await fetch(`${baseUrl}:runQuery`, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(query)
      })
      
      const results = await response.json()
      if (results[0]?.document) {
        const docPath = results[0].document.name
        const bookmarkId = docPath.split('/').pop()
        return { success: true, bookmarkId }
      }
      return { success: true, bookmarkId: null }
    }
    
    if (request.method === 'save') {
      const data = request.data
      const fields = {
        userId: { stringValue: user.uid },
        type: { stringValue: data.type },
        slug: { stringValue: data.slug },
        name: { stringValue: data.name },
        url: { stringValue: data.url },
        savedAt: { timestampValue: new Date().toISOString() }
      }
      if (data.image) fields.image = { stringValue: data.image }
      if (data.note) fields.note = { stringValue: data.note }
      
      const response = await fetch(`${baseUrl}/userBookmarks`, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ fields })
      })
      
      const result = await response.json()
      if (result.error) {
        return { success: false, error: result.error.message }
      }
      return { success: true }
    }
    
    if (request.method === 'remove') {
      // First find the bookmark
      const query = {
        structuredQuery: {
          from: [{ collectionId: 'userBookmarks' }],
          where: {
            compositeFilter: {
              op: 'AND',
              filters: [
                { fieldFilter: { field: { fieldPath: 'userId' }, op: 'EQUAL', value: { stringValue: user.uid } } },
                { fieldFilter: { field: { fieldPath: 'url' }, op: 'EQUAL', value: { stringValue: request.url } } }
              ]
            }
          },
          limit: 1
        }
      }
      
      const queryResponse = await fetch(`${baseUrl}:runQuery`, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(query)
      })
      
      const results = await queryResponse.json()
      if (!results[0]?.document) {
        return { success: true } // Already removed
      }
      
      const docName = results[0].document.name
      
      // Delete it
      const deleteResponse = await fetch(`https://firestore.googleapis.com/v1/${docName}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      })
      
      return { success: deleteResponse.ok }
    }
    
    return { success: false, error: 'Unknown method' }
  } catch (err) {
    console.error('Bookmark error:', err)
    return { success: false, error: err.message }
  }
}

console.log('West Marches extension background script loaded')
